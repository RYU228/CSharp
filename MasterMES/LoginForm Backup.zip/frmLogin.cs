﻿using DevExpress.XtraEditors;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DSLibrary;

namespace DS_MES
{
    public partial class frmLogin : frmBase
    {
        #region 생성자
        public frmLogin()
        {
            InitializeComponent();
        }

        #endregion

        #region 오버라이드 이벤트
        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);

            if (AppConfig.IsDebugMode)
            {
                txtUserID.EditValue = "admin"; //"202202001"
                txtPassword.EditValue = "1";

                btnOk.PerformClick();
            }
        }

        #endregion

        #region 폼 컨트롤 이벤트
        /// <summary>
        /// 확인 버튼
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnOk_Click(object sender, EventArgs e)
        {
            try
            {
                var field = new Dictionary<string, bool>()
                {
                    { "UserID", txtUserID.EditValue.CString() == "" },
                    { "Password", txtPassword.EditValue.CString() == "" },
                };
                if (Utils.CheckField(field))
                    return;

                var inParams = new DbParamList();
                inParams.Add("@i_ProcessID", ProcessType.Exist, SqlDbType.Char);
                inParams.Add("@i_UserID", txtUserID.EditValue.CString(), SqlDbType.VarChar);
                inParams.Add("@i_Password", txtPassword.EditValue.CString(), SqlDbType.VarChar);

                var table = SqlHelper.GetDataTable("xp_User", inParams, out string retCode, out string retMsg);

                if (retCode == "00" || retCode == "88")
                {
                    // 사용자 및 로컬 컴퓨터 정보 
                    AppConfig.Login.UserID = txtUserID.EditValue.CString();
                    AppConfig.Login.UserName = retMsg;
                    AppConfig.Machine.ComputerName = Utils.GetComputerName();
                    AppConfig.Machine.LocalIP = Utils.GetLocalIP();

                    if (retCode == "88")
                        MsgBox.WarningMessage(retMsg.Localization());

                    // 환경설정 정보 
                    inParams = new DbParamList();
                    inParams.Add("@i_ProcessID", ProcessType.GetRow, SqlDbType.Char);
                    inParams.Add("@i_EmpNo", AppConfig.Login.UserID, SqlDbType.VarChar);

                    table = SqlHelper.GetDataTable("xp_Config", inParams, out retCode, out retMsg);

                    if (retCode == "00" && table != null && table.Rows.Count > 0)
                    {
                        AppConfig.App.MenuType = table.Rows[0]["MenuType"].CString();
                        AppConfig.App.AccordionMode = table.Rows[0]["AccordionMode"].CString();
                        AppConfig.App.FontName = table.Rows[0]["FontName"].CString();
                        AppConfig.App.FontSize = table.Rows[0]["FontSize"].CFloat();
                    }
                    else
                    {
                        // 최초 설정값이 없으면 기본 가로형으로 설정, 글꼴은 기본 글꼴이 정해지면 변경해야함
                        AppConfig.App.MenuType = "H";
                        AppConfig.App.AccordionMode = "O";
                        AppConfig.App.FontName = "IBM Plex Sans KR";
                        AppConfig.App.FontSize = 10.0f;
                    }

                    // 글꼴 변경
                    DevExpress.Utils.AppearanceObject.DefaultFont = new System.Drawing.Font(AppConfig.App.FontName, AppConfig.App.FontSize);

                    this.DialogResult = DialogResult.OK;
                }
                else
                {
                    MsgBox.ErrorMessage(retMsg.Localization());
                }
            }
            catch (Exception ex)
            {
                MsgBox.ErrorMessage(ex.CString());
            }
        }

        /// <summary>
        /// 취소 버튼
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void bntCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }

        #endregion
    }
}